package Main;

import java.io.PrintStream;

import java.util.Scanner;

//import coders.DecodeMode;
import coders.EncodeMode;


public class Main {

	private static PrintStream out = System.out;
	private static Scanner sc = new Scanner( System.in );
	
	public static void main(String[] args) {
		out.println("decode and files are in progress.");
		out.println("Select mode(1 = decode | 2 = encode | 4 = exit) ");
		int option = sc.nextInt();
		out.println("Please enter the frecuency in Hz:");
		double frecuency = Double.valueOf(sc.next());
		do {
		switch (option) {
			case 1: {
				//out.print(DecodeMode.run(out, sc));
				main(args);//while in progress
				break;
			}
			case 2: {
				String aux = EncodeMode.run(out, sc);
				out.print(aux);
				double time = EncodeMode.getCycles() * (1/frecuency);
				out.println("Time to execute: " + time);
				if (aux.equals("Encode binary: exit\n")) {
					option = 4;
				}
				break;
			}
			case 4: {
				break;//exit
			}
			default:
				System.err.println("Unexpected value: " + option);
				main(args);
			}
		} while(option != 4);
	}
	

}

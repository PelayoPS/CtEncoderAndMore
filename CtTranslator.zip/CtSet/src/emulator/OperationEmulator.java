package emulator;
import java.util.HashMap;

import coders.Steps;


public class OperationEmulator {

	private Registers registers;
	private Flags flags;
	private int lastOperationResult;
	
	private class Registers {
		protected HashMap<String, String> registers = new HashMap<String, String>();

		public Registers() {
			registers.put("R0", "0000");
			registers.put("R1", "0000");
			registers.put("R2", "0000");
			registers.put("R3", "0000");
			registers.put("R4", "0000");
			registers.put("R5", "0000");
			registers.put("R6", "0000");
			registers.put("R7", "0000");
		}
	}
	
	private class Flags {
		protected HashMap<String, String> flags = new HashMap<String, String>();

		public Flags() {
			flags.put("Z", "0");
			flags.put("C", "0");
			flags.put("O", "0");
			flags.put("S", "0");
		}
	}
	
	public OperationEmulator() {
		this.registers = new Registers();
		this.flags = new Flags();
	}
	
	private void checkFlags() {
		if (this.lastOperationResult < 0) {
			this.flags.flags.replace("S",
					this.flags.flags.get("S"), "1");
		}
		if (this.lastOperationResult > 65.535‬) {
			this.flags.flags.replace("O",
					this.flags.flags.get("O"), "1");
		}
	}
	
	private static String encodeMode() {
		out.println("Please use / as separator, breaks otherwise.");
		out.println("What to encode?  ");
		out.println("Use 'Ext' to exit.");
		String option = sc.next();
		try {
			String[] line = option.split("/");
			for (int i = 0; i < line.length; i++) {
				line[i] = line[i].toUpperCase();
			}
			System.out.print(Steps.getSteps(line));
			String key = line[0];
			String result;
			switch (key.substring(0, 3)) {
				case "EXT": {
					return "exit";
				}
				case "NOP": {
					result = "00000 00000000000"; 
					break;
				}
				case "MOV": {
					result = encodeMOV(line);
					break;
				}
				case "ADD": {
					result = encodeAdd(line); 
					break;
				}
				case "SUB": {
					result = encodeSub(line);
					break;
				}
				case "OR ": {
					result = encodeOr(line);
					break;
				}
				case "AND": {
					result = encodeAnd(line);
					break;
				}
				case "XOR": {
					result = encodeXor(line);
					break;
				}
				case "CMP": {
					result = encodeCmp(line);
					break;
				}
				case "NOT": {
					result = encodeNot(line);
					break;
				}
				case "INC": {
					result = encodeInc(line);
					break;
				}
				case "DEC": {
					result = dec(line);
					break;
				}
				case "NEG": {
					//result = encodeNeg(line);
					System.out.println("In progress...");
					break;
				}
				case "CLI": {
					//result = encodeCli();
					System.out.println("In progress...");
					break;
				}
				case "STI": {
					//result = encodeSti();
					System.out.println("In progress...");
					break;
				}
				case "INT": {
					//result = encodeInt(line);
					System.out.println("In progress...");
					break;
				}
				case "IRE": {//IRET
					//result = encodeIret();
					System.out.println("In progress...");
					break;
				}
				case "RET": {
					//result = encodeRet();
					System.out.println("In progress...");
					break;
				}
				case "JMP": {
					//result = jmp(line);
					System.out.println("In progress...");
					break;
				}
				case "CALL": {
					//result = encodeCall(line);
					System.out.println("In progress...");
					break;
				}
				default:
					if (key.substring(0, 2).equals("BR")) {
						//result = encodeBrs(line);
						System.out.println("In progress...");
						break;
					}
					System.out.println("Bad input, repeat");
					throw new IllegalArgumentException();
					
				}
			return result;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			throw new IllegalArgumentException();
		}	
	}	
	
	private int toIntFromHex(String hex) {
		return Integer.decode("0x"+hex);
	}
	
	private String encodeHex(int number) {
		return Integer.toHexString(number).toUpperCase();
	}
	
	/**
	 * from register to register
	 * @param des
	 * @param src
	 */
	public void movRToR(String des, String src) {
		this.registers.registers.replace(des, 
				this.registers.registers.get(des), 
				this.registers.registers.get(src));
	}
	
	/**
	 * from memory to register 
	 * @param des
	 * @param src
	 */
	public void movMToR(String des, String src) {
		this.registers.registers.replace(des, 
				this.registers.registers.get(des), 
				this.registers.registers.get(src));
	}
	
	/**
	 * from register to memory 
	 * @param des
	 * @param src
	 */
	public void movRToM(String des, String src) {
		this.registers.registers.replace(des, 
				this.registers.registers.get(des), 
				this.registers.registers.get(src));
	}
	
	/**
	 * from hex low to register 
	 * @param des
	 * @param src
	 */
	public void movl(String des, String src) {
		this.registers.registers.replace(des, 
				this.registers.registers.get(des), 
				("00"+this.registers.registers.get(src)));
	}
	
	/**
	 * from hex high to register 
	 * @param des
	 * @param src
	 */
	public void movh(String des, String src) {
		this.registers.registers.replace(des, 
				this.registers.registers.get(des), 
				(this.registers.registers.get(src) + "00"));
	}
	
	/**
	 * adds in hexadecimal
	 * @param des
	 * @param reg1
	 * @param reg2
	 */
	public void add(String des, String reg1, String reg2) {
		int reg1Value = toIntFromHex(this.registers.registers.get(reg1));
		int reg2Value = toIntFromHex(this.registers.registers.get(reg2));
		this.lastOperationResult = reg1Value + reg2Value;
		String hexResult = encodeHex(lastOperationResult);
		this.registers.registers.replace(des,
				this.registers.registers.get(des), hexResult);
	}
	
	/**
	 * subtracts in hexadecimal
	 * @param des
	 * @param reg1
	 * @param reg2
	 */
	public void sub(String des, String reg1, String reg2) {
		int reg1Value = toIntFromHex(this.registers.registers.get(reg1));
		int reg2Value = toIntFromHex(this.registers.registers.get(reg2));
		this.lastOperationResult = reg1Value - reg2Value;
		String hexResult = encodeHex(lastOperationResult);
		this.registers.registers.replace(des,
				this.registers.registers.get(des), hexResult);
	}
	
	/**
	 * or operation in hexadecimal
	 * @param des
	 * @param reg1
	 * @param reg2
	 */
	public void or(String des, String reg1, String reg2) {
		int reg1Value = toIntFromHex(this.registers.registers.get(reg1));
		int reg2Value = toIntFromHex(this.registers.registers.get(reg2));
		this.lastOperationResult = reg1Value | reg2Value;
		String hexResult = encodeHex(lastOperationResult);
		this.registers.registers.replace(des,
				this.registers.registers.get(des), hexResult);
	}
	
	/**
	 * and operation in hexadecimal
	 * @param des
	 * @param reg1
	 * @param reg2
	 */
	public void and(String des, String reg1, String reg2) {
		int reg1Value = toIntFromHex(this.registers.registers.get(reg1));
		int reg2Value = toIntFromHex(this.registers.registers.get(reg2));
		this.lastOperationResult = reg1Value & reg2Value;
		String hexResult = encodeHex(lastOperationResult);
		this.registers.registers.replace(des,
				this.registers.registers.get(des), hexResult);
	}
	
	/**
	 * and operation in hexadecimal
	 * @param des
	 * @param reg1
	 * @param reg2
	 */
	public void xor(String des, String reg1, String reg2) {
		int reg1Value = toIntFromHex(this.registers.registers.get(reg1));
		int reg2Value = toIntFromHex(this.registers.registers.get(reg2));
		this.lastOperationResult = reg1Value ^ reg2Value;
		String hexResult = encodeHex(lastOperationResult);
		this.registers.registers.replace(des,
				this.registers.registers.get(des), hexResult);
	}
	
	/**
	 * cmp operation in hexadecimal
	 * @param reg1
	 * @param reg2
	 */
	public void cmp(String reg1, String reg2) {
		int reg1Value = toIntFromHex(this.registers.registers.get(reg1));
		int reg2Value = toIntFromHex(this.registers.registers.get(reg2));
		int this.lastOperationResult = reg2Value - reg1Value;
		String hexResult = encodeHex(lastOperationResult);
	}
	
	/**
	 * not operation in hexadecimal
	 * @param des
	 */
	public void not(String desSrc) {
		int reg1Value = toIntFromHex(this.registers.registers.get(desSrc));
		this.lastOperationResult = ~reg1Value;
		String hexResult = encodeHex(lastOperationResult);
		this.registers.registers.replace(desSrc,
				this.registers.registers.get(desSrc), hexResult);
	}
	
	/**
	 * inc operation in hexadecimal
	 * @param des
	 */
	public void inc(String desSrc) {
		int reg1Value = toIntFromHex(this.registers.registers.get(desSrc));
		this.lastOperationResult = reg1Value + 1;
		String hexResult = encodeHex(lastOperationResult);
		this.registers.registers.replace(desSrc,
				this.registers.registers.get(desSrc), hexResult);
	}
	
	/**
	 * dec operation in hexadecimal
	 * @param des
	 */
	public void dec(String desSrc) {
		int reg1Value = toIntFromHex(this.registers.registers.get(desSrc));
		this.lastOperationResult = reg1Value - 1;
		String hexResult = encodeHex(lastOperationResult);
		this.registers.registers.replace(desSrc,
				this.registers.registers.get(desSrc), hexResult);
	}
	
	/**
	 * neg operation in hexadecimal
	 * @param des
	 */
	public void neg(String desSrc) {
		not(desSrc);
		inc(desSrc);
	}
}

package coders;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class EncodeMode {
	
	private static PrintStream out;
	private static Scanner sc;
	private static String internalEncoding;
	private static String steps;

	public static String run(PrintStream outStream, Scanner scanner) {
		out = outStream;
		sc = scanner;
		String aux = String.format("Encode binary: %s", encodeMode());
		if (!aux.equals("Encode binary: exit")) {
			String aux2 = String.format("Encode hex: %s", encodeHex());
			return aux + "\n" + aux2 + "\n";
		}
		return aux + "\n" + steps;
		
	}
	
	public static double getCycles() {
		return Steps.getCycles();
	}
	
	private static String encodeMode() {
		out.println("Please use / as separator, breaks otherwise.");
		out.println("What to encode?  ");
		out.println("Use 'Ext' to exit.");
		String option = sc.next();
		try {
			String[] line = option.split("/");
			for (int i = 0; i < line.length; i++) {
				line[i] = line[i].toUpperCase();
			}
			System.out.print(Steps.getSteps(line));
			String key = line[0];
			String result;
			switch (key.substring(0, 3)) {
				case "EXT": {
					return "exit";
				}
				case "NOP": {
					result = "00000 00000000000"; 
					break;
				}
				case "MOV": {
					result = encodeMOV(line);
					break;
				}
				case "ADD": {
					result = encodeAdd(line); 
					break;
				}
				case "SUB": {
					result = encodeSub(line);
					break;
				}
				case "OR ": {
					result = encodeOr(line);
					break;
				}
				case "AND": {
					result = encodeAnd(line);
					break;
				}
				case "XOR": {
					result = encodeXor(line);
					break;
				}
				case "CMP": {
					result = encodeCmp(line);
					break;
				}
				case "NOT": {
					result = encodeNot(line);
					break;
				}
				case "INC": {
					result = encodeInc(line);
					break;
				}
				case "DEC": {
					result = encodeDec(line);
					break;
				}
				case "NEG": {
					result = encodeNeg(line);
					break;
				}
				case "CLI": {
					result = encodeCli();
					break;
				}
				case "STI": {
					result = encodeSti();
					break;
				}
				case "INT": {
					result = encodeInt(line);
					break;
				}
				case "IRE": {//IRET
					result = encodeIret();
					break;
				}
				case "RET": {
					result = encodeRet();
					break;
				}
				case "JMP": {
					result = encodeJmp(line);
					break;
				}
				case "CALL": {
					result = encodeCall(line);
					break;
				}
				default:
					if (key.substring(0, 2).equals("BR")) {
						result = encodeBrs(line);
						internalEncoding = result;
						break;
					}
					out.println("Bad input, repeat");
					result = encodeMode();
				}
			internalEncoding = result;
			return result;
		} catch (Exception e) {
			System.err.print(e.getMessage());
			out.println("Error, repeat");
			return encodeMode();
		}	
	}	

	private static String encodeBrs(String[] line) {
		HashMap<String, String> conds = new HashMap<String, String>();
		conds.put("BRC", "000");
		conds.put("BRNC", "001");
		conds.put("BRO", "010");
		conds.put("BRNO", "011");
		conds.put("BRZ", "100");
		conds.put("BRNZ", "101");
		conds.put("BRS", "110");
		conds.put("BRNS", "111");
		return String.format("11110 %s %s",
				conds.get(line[0]),
				encodeNumber(line[1]));
	}

	private static String encodeCall(String[] line) {
		switch (line[1].charAt(0)) {
		case 'R': {
			return String.format("11011 %s 00000000",
					encodeRegister(line[1].charAt(1)));
		}
		default:
			return String.format("11010 000 %s",
					encodeNumber(line[1]));
	}
	}

	private static String encodeJmp(String[] line) {
		switch (line[1].charAt(0)) {
			case 'R': {
				return String.format("11001 %s 00000000",
						encodeRegister(line[1].charAt(1)));
			}
			default:
				return String.format("11000 000 %s",
						encodeNumber(line[1]));
		}
	}

	private static String encodeRet() {
		return "11100 00000000000";
	}

	private static String encodeIret() {
		return "10111 00000000000 ";
	}

	private static String encodeInt(String[] line) {
		// 10110 000 Inm8 
		return String.format("10011 %s 00000000",
				encodeNumber(line[1]));
	}

	private static String encodeSti() {
		return "10101 00000000000";
	}

	private static String encodeCli() {
		return "10100 00000000000";
	}

	private static String encodeNeg(String[] line) {
		// 10011 Rd/s 00000000
		return String.format("10011 %s 00000000",
				encodeRegister(line[1].charAt(1)));
	}

	private static String encodeDec(String[] line) {
		// 10010 Rd/s 00000000
		return String.format("10010 %s 00000000",
				encodeRegister(line[1].charAt(1)));
	}

	private static String encodeInc(String[] line) {
		// 10001 Rd/s 00000000 I
		return String.format("10001 %s 00000000",
				encodeRegister(line[1].charAt(1)));
	}

	private static String encodeNot(String[] line) {
		// 10000 Rd/s 00000000
		return String.format("10000 %s 00000000",
				encodeRegister(line[1].charAt(1))); 
	}


	private static String encodeCmp(String[] line) {
		// 01101 Rs1 Rs2 000 00
		return String.format("01101 %s 000 00",
				encodeRegisters(line[1].charAt(1),line[2].charAt(1))); 
	}

	private static String encodeXor(String[] line) {
		// 01100 Rd Rs1 Rs2 00
		return String.format("01100 %s %s 00",
				encodeRegister(line[1].charAt(1)),			//Rd
				encodeRegisters(line[2].charAt(1),line[3].charAt(1))); //other
	}

	private static String encodeAnd(String[] line) {
		// 01011 Rd Rs1 Rs2 00 
		return String.format("01011 %s %s 00",
				encodeRegister(line[1].charAt(1)),			//Rd
				encodeRegisters(line[2].charAt(1),line[3].charAt(1))); //other
	}

	private static String encodeOr(String[] line) {
		// 01010 Rd Rs1 Rs2 00 
		return String.format("01010 %s %s 00",
				encodeRegister(line[1].charAt(1)),			//Rd
				encodeRegisters(line[2].charAt(1),line[3].charAt(1))); //other
	}

	private static String encodeSub(String[] line) {
		// 01001 Rd Rs1 Rs2 00
		return String.format("01001 %s %s 00",
				encodeRegister(line[1].charAt(1)),			//Rd
				encodeRegisters(line[2].charAt(1),line[3].charAt(1))); //other
	}

	private static String encodeAdd(String[] line) {
		// 01000 Rd Rs1 Rs2 00
		return String.format("01000 %s %s 00",
				encodeRegister(line[1].charAt(1)),			//Rd
				encodeRegisters(line[2].charAt(1),line[3].charAt(1))); //other
	}

	private static String encodeMOV(String[] line) {
		switch (line[0]) {
			case "MOV": {
				switch (line[1].charAt(0)) {
					case 'R': {
						switch (line[2].charAt(0)) {
							case '[': {
								return String.format("00010 %s 00000",
										encodeRegisters(line[1].charAt(1),line[2].charAt(2)));
							}
							case 'R': {
								return String.format("00001 %s 00000",encodeRegisters(line[1].charAt(1),line[2].charAt(1)));
							}
							default:
								throw new IllegalArgumentException("Unexpected value: " + line[2].charAt(0));
							}
					}
					case '[': {
						return String.format("00011 %s 00000",encodeRegisters(line[1].charAt(2),line[2].charAt(1)));
					}
					default:
						throw new IllegalArgumentException("Unexpected value: " + line[1].charAt(0));
					}
			}
			case "MOVL": {
				return String.format("00100 %s %s",encodeRegister(line[1].charAt(1)), encodeNumber(line[2]));
			}
			case "MOVH": {
				return String.format("00101 %s %s",encodeRegister(line[1].charAt(1)), encodeNumber(line[2]));
			}
			default:
				throw new IllegalArgumentException("Unexpected value: " + line[0]);
			}		
	}

	private static String encodeRegisters(char charAt, char charAt2) {
		int left = Integer.valueOf(charAt);
		int left1 = Integer.valueOf(charAt2);

		if (left < 48 || left > 55) {
			throw new IllegalArgumentException("Invalid register: R" + left);
		}
		if (left1 < 48 || left1 > 55) {
			throw new IllegalArgumentException("Invalid register: R" + charAt2);
		}
		String aux = Integer.toBinaryString(left & 0xFF);
		String aux1 = Integer.toBinaryString(left1 & 0xFF);
		return String.format("%s %s",aux.substring(3),aux1.substring(3));
	}
	
	private static String encodeRegister(char charAt) {
		int left = Integer.valueOf(charAt);
		String aux = Integer.toBinaryString(left & 0xFF);
		return aux.substring(3);
	}
	
	private static String encodeNumber(String number) {
		String aux = Integer.toBinaryString(Integer.valueOf(number) & 0xFF);
		String zero = "";
		int counter = 8 - aux.length();
		while (counter > 0) {
			zero += "0";
			counter--;
		}
		aux = zero + aux;
		return aux;
	}
	
	private static String encodeHex() {
		List<String> aux = getParts(internalEncoding);
		String hexStr = new String();
		for (String s : aux) {
			int decimal = Integer.parseInt(s,2);
			hexStr += Integer.toHexString(decimal).toUpperCase();
		}
		return hexStr;
	}
	
	private static List<String> getParts(String code) {
		code = code.replaceAll("\\s","");
		List<String> aux = new ArrayList<String>();
		aux.add(code.substring(0, 4));
		aux.add(code.substring(4,8));
		aux.add(code.substring(8, 12));
		aux.add(code.substring(12, 16));
		return aux;
		
	}
}

package coders;

import java.io.PrintStream;
import java.util.Scanner;

public class DecodeMode {
	
	private static PrintStream out;
	private static Scanner sc;

	public static String run(PrintStream outStream, Scanner scanner) {
		out = outStream;
		sc = scanner;
		return null;
		//return decodeMode();
	}
}
